import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Loader2, Send, Trash2, Plus, MessageSquare, ChevronLeft } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { useState } from "react";
import { toast } from "sonner";
import { useLocation } from "wouter";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";

export default function Support() {
  const { user, isAuthenticated } = useAuth();
  const [, setLocation] = useLocation();
  const [selectedTicketId, setSelectedTicketId] = useState<number | null>(null);
  const [messageText, setMessageText] = useState("");

  // Fetch tickets
  const { data: tickets, isLoading: ticketsLoading, refetch: refetchTickets } = 
    trpc.support.getMyTickets.useQuery(undefined, { enabled: isAuthenticated });

  // Fetch messages for selected ticket
  const { data: messages, isLoading: messagesLoading, refetch: refetchMessages } = 
    trpc.support.getTicketMessages.useQuery(
      { ticketId: selectedTicketId! },
      { enabled: !!selectedTicketId }
    );

  // Mutations
  const createTicketMutation = trpc.support.createTicket.useMutation({
    onSuccess: () => {
      toast.success("تم إنشاء التذكرة بنجاح!");
      refetchTickets();
    },
    onError: (error) => {
      toast.error(error.message || "فشل إنشاء التذكرة");
    },
  });

  const addMessageMutation = trpc.support.addMessage.useMutation({
    onSuccess: () => {
      setMessageText("");
      refetchMessages();
    },
    onError: (error) => {
      toast.error(error.message || "فشل إرسال الرسالة");
    },
  });

  const deleteMessageMutation = trpc.support.deleteMessage.useMutation({
    onSuccess: () => {
      toast.success("تم حذف الرسالة!");
      refetchMessages();
    },
    onError: (error) => {
      toast.error(error.message || "فشل حذف الرسالة");
    },
  });

  const handleCreateTicket = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    const subject = formData.get("subject") as string;

    if (!subject.trim()) {
      toast.error("أدخل موضوع التذكرة");
      return;
    }

    createTicketMutation.mutate({ subject });
  };

  const handleSendMessage = () => {
    if (!messageText.trim() || !selectedTicketId) {
      toast.error("أدخل الرسالة");
      return;
    }

    addMessageMutation.mutate({
      ticketId: selectedTicketId,
      message: messageText,
    });
  };

  const handleDeleteMessage = (messageId: number) => {
    if (confirm("هل تريد حذف هذه الرسالة؟")) {
      deleteMessageMutation.mutate({ messageId });
    }
  };

  if (!selectedTicketId) {
    return (
      <div className="min-h-screen bg-background">
        {/* Header */}
        <header className="sticky top-0 z-50 bg-card/80 backdrop-blur border-b border-border">
          <div className="container mx-auto px-4 py-4 flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-foreground">الدعم الفني</h1>
              <p className="text-sm text-muted-foreground">تواصل معنا لحل مشاكلك</p>
            </div>
            <Button variant="outline" onClick={() => setLocation("/")}>
              <ChevronLeft className="w-4 h-4 mr-2" />
              العودة
            </Button>
          </div>
        </header>

        {/* Content */}
        <main className="container mx-auto px-4 py-8">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-2xl font-bold text-foreground">تذاكرك</h2>
            <Dialog>
              <DialogTrigger asChild>
                <Button className="bg-gradient-to-r from-primary to-accent">
                  <Plus className="w-4 h-4 mr-2" />
                  تذكرة جديدة
                </Button>
              </DialogTrigger>
              <DialogContent className="bg-card border-border">
                <DialogHeader>
                  <DialogTitle className="text-foreground">إنشاء تذكرة دعم جديدة</DialogTitle>
                </DialogHeader>
                <form onSubmit={handleCreateTicket} className="space-y-4">
                  <div>
                    <label className="text-foreground text-sm font-medium">الموضوع</label>
                    <Input
                      name="subject"
                      placeholder="اشرح مشكلتك بإيجاز"
                      className="bg-background border-border text-foreground"
                    />
                  </div>
                  <Button type="submit" className="w-full bg-gradient-to-r from-primary to-accent">
                    إنشاء التذكرة
                  </Button>
                </form>
              </DialogContent>
            </Dialog>
          </div>

          {ticketsLoading ? (
            <div className="flex justify-center py-12">
              <Loader2 className="animate-spin w-8 h-8 text-accent" />
            </div>
          ) : tickets && tickets.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {tickets.map((ticket) => (
                <Card
                  key={ticket.id}
                  onClick={() => setSelectedTicketId(ticket.id)}
                  className="bg-card border-border p-4 cursor-pointer hover:border-accent transition-colors"
                >
                  <div className="flex items-start justify-between mb-2">
                    <h3 className="font-semibold text-foreground">{ticket.subject}</h3>
                    <span className={`text-xs px-2 py-1 rounded-full ${
                      ticket.status === "open" ? "bg-accent/20 text-accent" :
                      ticket.status === "in_progress" ? "bg-yellow-500/20 text-yellow-400" :
                      "bg-green-500/20 text-green-400"
                    }`}>
                      {ticket.status === "open" ? "مفتوحة" :
                       ticket.status === "in_progress" ? "قيد المعالجة" : "مغلقة"}
                    </span>
                  </div>
                  <p className="text-xs text-muted-foreground">
                    {new Date(ticket.createdAt).toLocaleDateString("ar-SA")}
                  </p>
                </Card>
              ))}
            </div>
          ) : (
            <Card className="bg-card border-border p-8 text-center">
              <MessageSquare className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
              <p className="text-muted-foreground mb-4">لا توجد تذاكر دعم</p>
              <Dialog>
                <DialogTrigger asChild>
                  <Button className="bg-gradient-to-r from-primary to-accent">
                    إنشاء تذكرة الآن
                  </Button>
                </DialogTrigger>
                <DialogContent className="bg-card border-border">
                  <DialogHeader>
                    <DialogTitle className="text-foreground">إنشاء تذكرة دعم جديدة</DialogTitle>
                  </DialogHeader>
                  <form onSubmit={handleCreateTicket} className="space-y-4">
                    <div>
                      <label className="text-foreground text-sm font-medium">الموضوع</label>
                      <Input
                        name="subject"
                        placeholder="اشرح مشكلتك بإيجاز"
                        className="bg-background border-border text-foreground"
                      />
                    </div>
                    <Button type="submit" className="w-full bg-gradient-to-r from-primary to-accent">
                      إنشاء التذكرة
                    </Button>
                  </form>
                </DialogContent>
              </Dialog>
            </Card>
          )}
        </main>
      </div>
    );
  }

  // Chat View
  const selectedTicket = tickets?.find(t => t.id === selectedTicketId);

  return (
    <div className="min-h-screen bg-background flex flex-col">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-card/80 backdrop-blur border-b border-border">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <button
              onClick={() => setSelectedTicketId(null)}
              className="p-2 hover:bg-background rounded-lg transition-colors"
            >
              <ChevronLeft className="w-5 h-5 text-muted-foreground" />
            </button>
            <div>
              <h1 className="text-xl font-bold text-foreground">{selectedTicket?.subject}</h1>
              <p className="text-xs text-muted-foreground">
                {selectedTicket?.status === "open" ? "مفتوحة" :
                 selectedTicket?.status === "in_progress" ? "قيد المعالجة" : "مغلقة"}
              </p>
            </div>
          </div>
        </div>
      </header>

      {/* Messages */}
      <main className="flex-1 container mx-auto px-4 py-6 overflow-y-auto">
        {messagesLoading ? (
          <div className="flex justify-center py-12">
            <Loader2 className="animate-spin w-8 h-8 text-accent" />
          </div>
        ) : messages && messages.length > 0 ? (
          <div className="space-y-4">
            {messages.map((message) => (
              <div
                key={message.id}
                className={`flex ${message.senderId === user?.id ? "justify-end" : "justify-start"}`}
              >
                <div
                  className={`max-w-xs lg:max-w-md px-4 py-3 rounded-lg ${
                    message.senderId === user?.id
                      ? "bg-gradient-to-r from-primary to-accent text-white"
                      : "bg-card border border-border text-foreground"
                  }`}
                >
                  <p className="text-sm mb-2">{message.message}</p>
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-xs opacity-70">
                      {new Date(message.createdAt).toLocaleTimeString("ar-SA")}
                    </span>
                    {message.senderId === user?.id && (
                      <button
                        onClick={() => handleDeleteMessage(message.id)}
                        className="p-1 hover:opacity-70 transition-opacity"
                      >
                        <Trash2 className="w-3 h-3" />
                      </button>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-12">
            <MessageSquare className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
            <p className="text-muted-foreground">لا توجد رسائل بعد</p>
          </div>
        )}
      </main>

      {/* Input */}
      <div className="sticky bottom-0 bg-card border-t border-border p-4">
        <div className="container mx-auto flex gap-2">
          <input
            type="text"
            value={messageText}
            onChange={(e) => setMessageText(e.target.value)}
            onKeyPress={(e) => {
              if (e.key === "Enter" && !e.shiftKey) {
                e.preventDefault();
                handleSendMessage();
              }
            }}
            placeholder="اكتب رسالتك..."
            className="flex-1 bg-background border border-border rounded-lg px-4 py-2 text-foreground placeholder-muted-foreground focus:outline-none focus:border-accent"
          />
          <Button
            onClick={handleSendMessage}
            disabled={addMessageMutation.isPending}
            className="bg-gradient-to-r from-primary to-accent"
          >
            <Send className="w-4 h-4" />
          </Button>
        </div>
      </div>
    </div>
  );
}

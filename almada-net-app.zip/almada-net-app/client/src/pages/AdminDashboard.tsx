import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Loader2, Plus, Edit2, Trash2, BarChart3, Package, Users, LogOut, ChevronLeft, MessageSquare } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { useState, useEffect } from "react";
import { toast } from "sonner";
import { useLocation } from "wouter";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";

export default function AdminDashboard() {
  const { user, isAuthenticated, logout } = useAuth();
  const [, setLocation] = useLocation();
  const [activeTab, setActiveTab] = useState<"categories" | "cards" | "stats" | "users">("categories");

  // Redirect if not admin
  useEffect(() => {
    if (isAuthenticated && user?.role !== "admin") {
      setLocation("/");
    }
  }, [isAuthenticated, user?.role, setLocation]);

  if (isAuthenticated && user?.role !== "admin") {
    return null;
  }

  // Fetch data
  const { data: categories, isLoading: categoriesLoading, refetch: refetchCategories } = 
    trpc.categories.list.useQuery();

  const { data: stats, isLoading: statsLoading } = 
    trpc.purchases.getStats.useQuery();

  // Mutations
  const createCategoryMutation = trpc.categories.create.useMutation({
    onSuccess: () => {
      toast.success("تم إنشاء الفئة بنجاح!");
      refetchCategories();
    },
    onError: (error) => {
      toast.error(error.message || "فشل إنشاء الفئة");
    },
  });

  const deleteCategoryMutation = trpc.categories.delete.useMutation({
    onSuccess: () => {
      toast.success("تم حذف الفئة بنجاح!");
      refetchCategories();
    },
    onError: (error) => {
      toast.error(error.message || "فشل حذف الفئة");
    },
  });

  const addCardsMutation = trpc.cards.addBulk.useMutation({
    onSuccess: () => {
      toast.success("تم إضافة الكروت بنجاح!");
    },
    onError: (error) => {
      toast.error(error.message || "فشل إضافة الكروت");
    },
  });

  const handleCreateCategory = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    
    createCategoryMutation.mutate({
      name: formData.get("name") as string,
      description: formData.get("description") as string,
      basePrice: formData.get("basePrice") as string,
      discountPercentage: formData.get("discountPercentage") as string,
      finalPrice: formData.get("finalPrice") as string,
      offerText: formData.get("offerText") as string,
    });
  };

  const handleAddCards = (categoryId: number, e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    const codesText = formData.get("codes") as string;
    const codes = codesText.split("\n").map(c => c.trim()).filter(c => c);

    if (codes.length === 0) {
      toast.error("أضف على الأقل كرت واحد");
      return;
    }

    addCardsMutation.mutate({
      categoryId,
      codes,
    });
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-card/80 backdrop-blur border-b border-border">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-foreground">لوحة التحكم</h1>
            <p className="text-sm text-muted-foreground">إدارة النظام</p>
          </div>
          <button
            onClick={logout}
            className="p-2 hover:bg-background rounded-lg transition-colors"
          >
            <LogOut className="w-5 h-5 text-muted-foreground hover:text-foreground" />
          </button>
        </div>
      </header>

      {/* Tabs */}
      <div className="border-b border-border bg-card/50">
        <div className="container mx-auto px-4">
          <div className="flex gap-4 overflow-x-auto">
            {[
              { id: "categories", label: "الفئات", icon: Package },
              { id: "cards", label: "الكروت", icon: BarChart3 },
              { id: "stats", label: "الإحصائيات", icon: BarChart3 },
              { id: "users", label: "المستخدمون", icon: Users },
            ].map(({ id, label, icon: Icon }) => (
              <button
                key={id}
                onClick={() => setActiveTab(id as any)}
                className={`flex items-center gap-2 px-4 py-4 border-b-2 transition-colors whitespace-nowrap ${
                  activeTab === id
                    ? "border-accent text-accent"
                    : "border-transparent text-muted-foreground hover:text-foreground"
                }`}
              >
                <Icon className="w-4 h-4" />
                {label}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Content */}
      <main className="container mx-auto px-4 py-8">
        {/* Categories Tab */}
        {activeTab === "categories" && (
          <div>
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-2xl font-bold text-foreground">إدارة الفئات</h2>
              <Dialog>
                <DialogTrigger asChild>
                  <Button className="bg-gradient-to-r from-primary to-accent">
                    <Plus className="w-4 h-4 mr-2" />
                    فئة جديدة
                  </Button>
                </DialogTrigger>
                <DialogContent className="bg-card border-border max-h-[90vh] overflow-y-auto">
                  <DialogHeader>
                    <DialogTitle className="text-foreground">إنشاء فئة جديدة</DialogTitle>
                  </DialogHeader>
                  <form onSubmit={handleCreateCategory} className="space-y-4">
                    <div>
                      <Label className="text-foreground">اسم الفئة</Label>
                      <Input name="name" placeholder="مثال: إنترنت 100 جيجا" className="bg-background border-border text-foreground" required />
                    </div>
                    <div>
                      <Label className="text-foreground">الوصف</Label>
                      <Textarea name="description" placeholder="وصف الفئة" className="bg-background border-border text-foreground" />
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label className="text-foreground">السعر الأساسي</Label>
                        <Input name="basePrice" type="number" step="0.01" placeholder="0.00" className="bg-background border-border text-foreground" required />
                      </div>
                      <div>
                        <Label className="text-foreground">نسبة الخصم %</Label>
                        <Input name="discountPercentage" type="number" step="0.01" placeholder="0" className="bg-background border-border text-foreground" />
                      </div>
                    </div>
                    <div>
                      <Label className="text-foreground">السعر النهائي</Label>
                      <Input name="finalPrice" type="number" step="0.01" placeholder="0.00" className="bg-background border-border text-foreground" required />
                    </div>
                    <div>
                      <Label className="text-foreground">نص العرض</Label>
                      <Input name="offerText" placeholder="مثال: عرض خاص" className="bg-background border-border text-foreground" />
                    </div>
                    <Button type="submit" className="w-full bg-gradient-to-r from-primary to-accent" disabled={createCategoryMutation.isPending}>
                      {createCategoryMutation.isPending ? "جاري الإنشاء..." : "إنشاء الفئة"}
                    </Button>
                  </form>
                </DialogContent>
              </Dialog>
            </div>

            {categoriesLoading ? (
              <div className="flex justify-center py-12">
                <Loader2 className="animate-spin w-8 h-8 text-accent" />
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {categories?.map((category) => (
                  <Card key={category.id} className="bg-card border-border p-4">
                    <h3 className="text-lg font-bold text-foreground mb-2">{category.name}</h3>
                    <p className="text-sm text-muted-foreground mb-4">{category.description}</p>
                    <div className="flex justify-between items-center mb-4">
                      <div>
                        <p className="text-xs text-muted-foreground">السعر</p>
                        <p className="text-lg font-bold text-accent">{category.finalPrice} ر.س</p>
                      </div>
                      {category.discountPercentage && parseFloat(category.discountPercentage) > 0 && (
                        <div className="text-right">
                          <p className="text-xs text-muted-foreground">الخصم</p>
                          <p className="text-lg font-bold text-green-400">{category.discountPercentage}%</p>
                        </div>
                      )}
                    </div>
                    <div className="flex gap-2">
                      <Dialog>
                        <DialogTrigger asChild>
                          <Button variant="outline" size="sm" className="flex-1">
                            <Plus className="w-4 h-4 mr-1" />
                            إضافة كروت
                          </Button>
                        </DialogTrigger>
                        <DialogContent className="bg-card border-border">
                          <DialogHeader>
                            <DialogTitle className="text-foreground">إضافة كروت للفئة</DialogTitle>
                          </DialogHeader>
                          <form onSubmit={(e) => handleAddCards(category.id, e)} className="space-y-4">
                            <div>
                              <Label className="text-foreground">الكروت (واحد لكل سطر)</Label>
                              <Textarea
                                name="codes"
                                placeholder="أدخل رموز الكروت&#10;واحد لكل سطر"
                                rows={8}
                                className="bg-background border-border text-foreground font-mono"
                                required
                              />
                            </div>
                            <Button type="submit" className="w-full bg-gradient-to-r from-primary to-accent" disabled={addCardsMutation.isPending}>
                              {addCardsMutation.isPending ? "جاري الإضافة..." : "إضافة الكروت"}
                            </Button>
                          </form>
                        </DialogContent>
                      </Dialog>
                      <Button
                        variant="destructive"
                        size="sm"
                        onClick={() => {
                          if (confirm("هل تريد حذف هذه الفئة؟")) {
                            deleteCategoryMutation.mutate({ id: category.id });
                          }
                        }}
                        disabled={deleteCategoryMutation.isPending}
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </Card>
                ))}
              </div>
            )}
          </div>
        )}

        {/* Cards Tab */}
        {activeTab === "cards" && (
          <div>
            <h2 className="text-2xl font-bold text-foreground mb-6">إدارة الكروت</h2>
            <Card className="bg-card border-border p-6 text-center">
              <p className="text-muted-foreground">يمكن إضافة الكروت من خلال تعديل الفئات</p>
            </Card>
          </div>
        )}

        {/* Stats Tab */}
        {activeTab === "stats" && (
          <div>
            <h2 className="text-2xl font-bold text-foreground mb-6">الإحصائيات</h2>
            {statsLoading ? (
              <div className="flex justify-center py-12">
                <Loader2 className="animate-spin w-8 h-8 text-accent" />
              </div>
            ) : (
              <div className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <Card className="bg-card border-border p-6">
                    <p className="text-muted-foreground mb-2">إجمالي المبيعات</p>
                    <p className="text-4xl font-bold text-accent">{stats?.totalPurchases || 0}</p>
                  </Card>
                  <Card className="bg-card border-border p-6">
                    <p className="text-muted-foreground mb-2">إجمالي الإيرادات</p>
                    <p className="text-4xl font-bold text-accent">{stats?.totalRevenue || 0} ر.س</p>
                  </Card>
                </div>

                {/* Category Stats */}
                <div>
                  <h3 className="text-xl font-bold text-foreground mb-4">إحصائيات الفئات</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {categories?.map((category) => {
                      const categoryPurchases = stats?.purchases?.filter((p: any) => p.categoryId === category.id) || [];
                      const categoryRevenue = categoryPurchases.reduce((sum: number, p: any) => sum + parseFloat(p.amount.toString()), 0);
                      return (
                        <Card key={category.id} className="bg-card border-border p-4">
                          <h4 className="font-semibold text-foreground mb-3">{category.name}</h4>
                          <div className="space-y-2">
                            <div className="flex justify-between">
                              <span className="text-sm text-muted-foreground">المبيعات:</span>
                              <span className="text-sm font-semibold text-accent">{categoryPurchases.length}</span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-sm text-muted-foreground">الإيرادات:</span>
                              <span className="text-sm font-semibold text-accent">{categoryRevenue} ر.س</span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-sm text-muted-foreground">السعر:</span>
                              <span className="text-sm font-semibold text-foreground">{category.finalPrice} ر.س</span>
                            </div>
                          </div>
                        </Card>
                      );
                    })}
                  </div>
                </div>
              </div>
            )}
          </div>
        )}

        {/* Users Tab */}
        {activeTab === "users" && (
          <div>
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-2xl font-bold text-foreground">المستخدمون</h2>
              <Button onClick={() => setLocation("/admin/support")} className="bg-gradient-to-r from-primary to-accent">
                <MessageSquare className="w-4 h-4 mr-2" />
                لوحة الدعم
              </Button>
            </div>
            <Card className="bg-card border-border p-6 text-center">
              <p className="text-muted-foreground">قريباً - إدارة أرصدة المستخدمين</p>
            </Card>
          </div>
        )}
      </main>
    </div>
  );
}

import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Loader2, Send, Trash2, ChevronLeft, MessageSquare } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { useState } from "react";
import { toast } from "sonner";
import { useLocation } from "wouter";

export default function AdminSupport() {
  const { user, isAuthenticated } = useAuth();
  const [, setLocation] = useLocation();
  const [selectedTicketId, setSelectedTicketId] = useState<number | null>(null);
  const [messageText, setMessageText] = useState("");

  // Redirect if not admin
  if (isAuthenticated && user?.role !== "admin") {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Card className="bg-card border-border p-8 text-center">
          <h1 className="text-2xl font-bold text-foreground mb-4">لا يمكنك الوصول</h1>
          <p className="text-muted-foreground mb-6">هذه الصفحة متاحة فقط للمسؤولين</p>
          <Button onClick={() => setLocation("/")} className="bg-gradient-to-r from-primary to-accent">
            العودة للصفحة الرئيسية
          </Button>
        </Card>
      </div>
    );
  }

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Card className="bg-card border-border p-8 text-center">
          <h1 className="text-2xl font-bold text-foreground mb-4">يرجى تسجيل الدخول</h1>
          <p className="text-muted-foreground mb-6">تحتاج إلى تسجيل دخول أولاً</p>
          <Button onClick={() => setLocation("/")} className="bg-gradient-to-r from-primary to-accent">
            تسجيل الدخول
          </Button>
        </Card>
      </div>
    );
  }

  // Fetch all tickets
  const { data: tickets, isLoading: ticketsLoading, refetch: refetchTickets } = 
    trpc.support.getAllTickets.useQuery(undefined, { enabled: isAuthenticated });

  // Fetch messages for selected ticket
  const { data: messages, isLoading: messagesLoading, refetch: refetchMessages } = 
    trpc.support.getTicketMessages.useQuery(
      { ticketId: selectedTicketId! },
      { enabled: !!selectedTicketId }
    );

  // Mutations
  const addMessageMutation = trpc.support.addMessage.useMutation({
    onSuccess: () => {
      setMessageText("");
      refetchMessages();
    },
    onError: (error) => {
      toast.error(error.message || "فشل إرسال الرسالة");
    },
  });

  const deleteMessageMutation = trpc.support.deleteMessage.useMutation({
    onSuccess: () => {
      toast.success("تم حذف الرسالة!");
      refetchMessages();
    },
    onError: (error) => {
      toast.error(error.message || "فشل حذف الرسالة");
    },
  });

  const updateStatusMutation = trpc.support.updateTicketStatus.useMutation({
    onSuccess: () => {
      toast.success("تم تحديث الحالة!");
      refetchTickets();
    },
    onError: (error) => {
      toast.error(error.message || "فشل تحديث الحالة");
    },
  });

  const handleSendMessage = () => {
    if (!messageText.trim() || !selectedTicketId) {
      toast.error("أدخل الرسالة");
      return;
    }

    addMessageMutation.mutate({
      ticketId: selectedTicketId,
      message: messageText,
    });
  };

  const handleDeleteMessage = (messageId: number) => {
    if (confirm("هل تريد حذف هذه الرسالة؟")) {
      deleteMessageMutation.mutate({ messageId });
    }
  };

  const selectedTicket = tickets?.find(t => t.id === selectedTicketId);

  if (!selectedTicketId) {
    return (
      <div className="min-h-screen bg-background">
        {/* Header */}
        <header className="sticky top-0 z-50 bg-card/80 backdrop-blur border-b border-border">
          <div className="container mx-auto px-4 py-4 flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-foreground">إدارة الدعم الفني</h1>
              <p className="text-sm text-muted-foreground">التذاكر والرسائل</p>
            </div>
            <Button variant="outline" onClick={() => setLocation("/admin")}>
              <ChevronLeft className="w-4 h-4 mr-2" />
              العودة
            </Button>
          </div>
        </header>

        {/* Content */}
        <main className="container mx-auto px-4 py-8">
          <h2 className="text-2xl font-bold text-foreground mb-6">التذاكر المفتوحة</h2>

          {ticketsLoading ? (
            <div className="flex justify-center py-12">
              <Loader2 className="animate-spin w-8 h-8 text-accent" />
            </div>
          ) : tickets && tickets.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {tickets.map((ticket) => (
                <Card
                  key={ticket.id}
                  onClick={() => setSelectedTicketId(ticket.id)}
                  className="bg-card border-border p-4 cursor-pointer hover:border-accent transition-colors"
                >
                  <div className="flex items-start justify-between mb-2">
                    <h3 className="font-semibold text-foreground">{ticket.subject}</h3>
                    <span className={`text-xs px-2 py-1 rounded-full ${
                      ticket.status === "open" ? "bg-accent/20 text-accent" :
                      ticket.status === "in_progress" ? "bg-yellow-500/20 text-yellow-400" :
                      ticket.status === "resolved" ? "bg-green-500/20 text-green-400" :
                      "bg-gray-500/20 text-gray-400"
                    }`}>
                      {ticket.status === "open" ? "مفتوحة" :
                       ticket.status === "in_progress" ? "قيد المعالجة" :
                       ticket.status === "resolved" ? "تم حلها" : "مغلقة"}
                    </span>
                  </div>
                  <p className="text-xs text-muted-foreground">
                    {new Date(ticket.createdAt).toLocaleDateString("ar-SA")}
                  </p>
                </Card>
              ))}
            </div>
          ) : (
            <Card className="bg-card border-border p-8 text-center">
              <MessageSquare className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
              <p className="text-muted-foreground">لا توجد تذاكر دعم</p>
            </Card>
          )}
        </main>
      </div>
    );
  }

  // Chat View
  return (
    <div className="min-h-screen bg-background flex flex-col">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-card/80 backdrop-blur border-b border-border">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <button
              onClick={() => setSelectedTicketId(null)}
              className="p-2 hover:bg-background rounded-lg transition-colors"
            >
              <ChevronLeft className="w-5 h-5 text-muted-foreground" />
            </button>
            <div>
              <h1 className="text-xl font-bold text-foreground">{selectedTicket?.subject}</h1>
              <div className="flex gap-2 mt-1">
                {["open", "in_progress", "resolved", "closed"].map((status) => (
                  <button
                    key={status}
                    onClick={() => {
                      if (selectedTicketId) {
                        updateStatusMutation.mutate({
                          ticketId: selectedTicketId,
                          status: status as any,
                        });
                      }
                    }}
                    className={`text-xs px-2 py-1 rounded transition-colors ${
                      selectedTicket?.status === status
                        ? "bg-accent text-background"
                        : "bg-card border border-border text-muted-foreground hover:border-accent"
                    }`}
                  >
                    {status === "open" ? "مفتوحة" :
                     status === "in_progress" ? "قيد المعالجة" :
                     status === "resolved" ? "تم حلها" : "مغلقة"}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Messages */}
      <main className="flex-1 container mx-auto px-4 py-6 overflow-y-auto">
        {messagesLoading ? (
          <div className="flex justify-center py-12">
            <Loader2 className="animate-spin w-8 h-8 text-accent" />
          </div>
        ) : messages && messages.length > 0 ? (
          <div className="space-y-4">
            {messages.map((message) => (
              <div
                key={message.id}
                className={`flex ${message.senderRole === "admin" ? "justify-end" : "justify-start"}`}
              >
                <div
                  className={`max-w-xs lg:max-w-md px-4 py-3 rounded-lg ${
                    message.senderRole === "admin"
                      ? "bg-gradient-to-r from-primary to-accent text-white"
                      : "bg-card border border-border text-foreground"
                  }`}
                >
                  <p className="text-xs opacity-70 mb-1">{message.senderRole === "admin" ? "أنت" : "المستخدم"}</p>
                  <p className="text-sm mb-2">{message.message}</p>
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-xs opacity-70">
                      {new Date(message.createdAt).toLocaleTimeString("ar-SA")}
                    </span>
                    <button
                      onClick={() => handleDeleteMessage(message.id)}
                      className="p-1 hover:opacity-70 transition-opacity"
                    >
                      <Trash2 className="w-3 h-3" />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-12">
            <MessageSquare className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
            <p className="text-muted-foreground">لا توجد رسائل بعد</p>
          </div>
        )}
      </main>

      {/* Input */}
      <div className="sticky bottom-0 bg-card border-t border-border p-4">
        <div className="container mx-auto flex gap-2">
          <input
            type="text"
            value={messageText}
            onChange={(e) => setMessageText(e.target.value)}
            onKeyPress={(e) => {
              if (e.key === "Enter" && !e.shiftKey) {
                e.preventDefault();
                handleSendMessage();
              }
            }}
            placeholder="اكتب ردك..."
            className="flex-1 bg-background border border-border rounded-lg px-4 py-2 text-foreground placeholder-muted-foreground focus:outline-none focus:border-accent"
          />
          <Button
            onClick={handleSendMessage}
            disabled={addMessageMutation.isPending}
            className="bg-gradient-to-r from-primary to-accent"
          >
            <Send className="w-4 h-4" />
          </Button>
        </div>
      </div>
    </div>
  );
}

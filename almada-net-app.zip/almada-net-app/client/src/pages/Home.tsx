import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Loader2, Wifi, Copy, Check, AlertCircle, LogOut } from "lucide-react";
import { getLoginUrl } from "@/const";
import { trpc } from "@/lib/trpc";
import { useState } from "react";
import { toast } from "sonner";
import { Link } from "wouter";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";

export default function Home() {
  const { user, loading, isAuthenticated, logout } = useAuth();
  const [copiedCardId, setCopiedCardId] = useState<number | null>(null);
  const [lastPurchase, setLastPurchase] = useState<any>(null);
  const [showPurchaseModal, setShowPurchaseModal] = useState(false);

  // Fetch data
  const { data: balance, isLoading: balanceLoading } = trpc.balance.getBalance.useQuery(undefined, {
    enabled: isAuthenticated,
  });

  const { data: categories, isLoading: categoriesLoading } = trpc.categories.list.useQuery();

  const { data: purchases, isLoading: purchasesLoading } = trpc.purchases.getHistory.useQuery(undefined, {
    enabled: isAuthenticated,
  });

  // Mutations
  const buyCardMutation = trpc.purchases.buyCard.useMutation({
    onSuccess: (data) => {
      toast.success("تم شراء الكرت بنجاح!");
      setLastPurchase(data.card);
      setShowPurchaseModal(true);
      // Invalidate queries to refresh data
      trpc.useUtils().balance.getBalance.invalidate();
      trpc.useUtils().purchases.getHistory.invalidate();
    },
    onError: (error) => {
      toast.error(error.message || "فشل شراء الكرت");
    },
  });

  const handleBuyCard = (categoryId: number) => {
    buyCardMutation.mutate({ categoryId });
  };

  const handleCopyCode = (code: string, cardId: number) => {
    navigator.clipboard.writeText(code);
    setCopiedCardId(cardId);
    toast.success("تم نسخ الرمز!");
    setTimeout(() => setCopiedCardId(null), 2000);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Loader2 className="animate-spin w-8 h-8 text-accent" />
      </div>
    );
  }

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-background flex flex-col items-center justify-center p-4">
        <div className="text-center max-w-md">
          <div className="w-16 h-16 bg-gradient-to-br from-primary to-accent rounded-2xl flex items-center justify-center mx-auto mb-6 shadow-lg shadow-accent/30">
            <Wifi className="w-8 h-8 text-white" />
          </div>
          <h1 className="text-3xl font-bold text-foreground mb-2">المدى نت</h1>
          <p className="text-muted-foreground mb-8">منصة موثوقة لشراء كروت الإنترنت بسهولة وأمان</p>
          <a href={getLoginUrl()}>
            <Button className="w-full bg-gradient-to-r from-primary to-accent hover:opacity-90">
              تسجيل الدخول
            </Button>
          </a>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-card/80 backdrop-blur border-b border-border">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-br from-primary to-accent rounded-lg flex items-center justify-center">
              <Wifi className="w-5 h-5 text-white" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-foreground">المدى نت</h1>
              <p className="text-xs text-muted-foreground">كروت إنترنت موثوقة</p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <div className="text-right">
              <p className="text-sm text-muted-foreground">رصيدك</p>
              <p className="text-lg font-bold text-accent">
                {balanceLoading ? "..." : `${balance?.balance || 0} ر.س`}
              </p>
            </div>
            <button
              onClick={logout}
              className="p-2 hover:bg-background rounded-lg transition-colors"
              title="تسجيل الخروج"
            >
              <LogOut className="w-5 h-5 text-muted-foreground hover:text-foreground" />
            </button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        {/* Welcome Section */}
        <div className="mb-8">
          <h2 className="text-2xl font-bold text-foreground mb-2">مرحباً {user?.name}</h2>
          <p className="text-muted-foreground">اختر الفئة المناسبة لك واشتري كرتك الآن</p>
        </div>

        {/* Categories Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
          {categoriesLoading ? (
            <div className="col-span-full flex justify-center py-12">
              <Loader2 className="animate-spin w-8 h-8 text-accent" />
            </div>
          ) : categories && categories.length > 0 ? (
            categories.map((category) => (
              <Card
                key={category.id}
                className="bg-card border-border hover:border-accent transition-all duration-300 overflow-hidden group"
              >
                <div className="p-6">
                  {/* Offer Badge */}
                  {category.offerText && (
                    <div className="inline-block px-3 py-1 bg-accent/20 text-accent text-xs font-bold rounded-full mb-4">
                      {category.offerText}
                    </div>
                  )}

                  {/* Category Name */}
                  <h3 className="text-xl font-bold text-foreground mb-2">{category.name}</h3>

                  {/* Description */}
                  {category.description && (
                    <p className="text-sm text-muted-foreground mb-4">{category.description}</p>
                  )}

                  {/* Price Section */}
                  <div className="mb-6">
                    {category.discountPercentage && parseFloat(category.discountPercentage) > 0 && (
                      <div className="flex items-center gap-2 mb-2">
                        <span className="text-sm text-muted-foreground line-through">
                          {category.basePrice} ر.س
                        </span>
                        <span className="text-xs bg-destructive/20 text-destructive px-2 py-1 rounded">
                          -{category.discountPercentage}%
                        </span>
                      </div>
                    )}
                    <div className="text-3xl font-bold text-accent">
                      {category.finalPrice} <span className="text-lg text-muted-foreground">ر.س</span>
                    </div>
                  </div>

                  {/* Buy Button */}
                  <Button
                    onClick={() => handleBuyCard(category.id)}
                    disabled={buyCardMutation.isPending}
                    className="w-full bg-gradient-to-r from-primary to-accent hover:opacity-90 text-white font-semibold"
                  >
                    {buyCardMutation.isPending ? (
                      <>
                        <Loader2 className="w-4 h-4 animate-spin mr-2" />
                        جاري الشراء...
                      </>
                    ) : (
                      "اشتري الآن"
                    )}
                  </Button>
                </div>
              </Card>
            ))
          ) : (
            <div className="col-span-full text-center py-12">
              <AlertCircle className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
              <p className="text-muted-foreground">لا توجد فئات متاحة حالياً</p>
            </div>
          )}
        </div>

        {/* Purchase History */}
        {purchases && purchases.length > 0 && (
          <div className="mt-12">
            <h3 className="text-2xl font-bold text-foreground mb-6">سجل المشتريات</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {purchases.map((purchase) => (
                <Card key={purchase.id} className="bg-card border-border p-4">
                  <div className="flex items-start justify-between mb-3">
                    <div>
                      <p className="text-sm text-muted-foreground">رمز الكرت</p>
                      <p className="font-mono text-sm text-foreground break-all">{purchase.cardCode}</p>
                    </div>
                    <button
                      onClick={() => handleCopyCode(purchase.cardCode, purchase.id)}
                      className="p-2 hover:bg-background rounded-lg transition-colors"
                    >
                      {copiedCardId === purchase.id ? (
                        <Check className="w-5 h-5 text-accent" />
                      ) : (
                        <Copy className="w-5 h-5 text-muted-foreground hover:text-accent" />
                      )}
                    </button>
                  </div>
                  <div className="flex justify-between items-center pt-3 border-t border-border">
                    <span className="text-sm text-muted-foreground">
                      {new Date(purchase.createdAt).toLocaleDateString("ar-SA")}
                    </span>
                    <span className="text-accent font-semibold">{purchase.amount} ر.س</span>
                  </div>
                </Card>
              ))}
            </div>
          </div>
        )}

        {/* Support Link */}
        <div className="mt-12 p-6 bg-card border border-border rounded-lg text-center">
          <p className="text-muted-foreground mb-4">هل تواجه مشكلة؟</p>
          <Link href="/support">
            <Button variant="outline" className="border-accent text-accent hover:bg-accent/10">
              تواصل مع الدعم
            </Button>
          </Link>
        </div>
      </main>

      {/* Purchase Success Modal */}
      <Dialog open={showPurchaseModal} onOpenChange={setShowPurchaseModal}>
        <DialogContent className="bg-card border-border max-w-md">
          <DialogHeader>
            <DialogTitle className="text-foreground text-center">تم الشراء بنجاح! 🎉</DialogTitle>
          </DialogHeader>
          <div className="space-y-6">
            <div className="text-center">
              <p className="text-muted-foreground mb-2">رمز الكرت الخاص بك:</p>
              <div className="bg-background border border-border rounded-lg p-4 font-mono text-sm text-accent break-all">
                {lastPurchase?.code}
              </div>
            </div>
            <Button
              onClick={() => {
                if (lastPurchase?.code) {
                  navigator.clipboard.writeText(lastPurchase.code);
                  toast.success("تم نسخ الرمز!");
                  setCopiedCardId(lastPurchase.id);
                  setTimeout(() => setCopiedCardId(null), 2000);
                }
              }}
              className="w-full bg-gradient-to-r from-primary to-accent"
            >
              {copiedCardId === lastPurchase?.id ? (
                <>
                  <Check className="w-4 h-4 mr-2" />
                  تم النسخ
                </>
              ) : (
                <>
                  <Copy className="w-4 h-4 mr-2" />
                  نسخ الرمز
                </>
              )}
            </Button>
            <p className="text-xs text-muted-foreground text-center">
              احفظ هذا الرمز في مكان آمن. يمكنك الوصول إليه دائماً من سجل المشتريات.
            </p>
            <Button
              onClick={() => setShowPurchaseModal(false)}
              variant="outline"
              className="w-full border-border"
            >
              إغلاق
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}

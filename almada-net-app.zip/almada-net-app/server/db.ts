import { eq, and, desc, isNull } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, users, userBalances, cardCategories, cards, purchases, supportTickets, supportMessages, adminLogs } from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    } else {
      // Check if this is the first user - make them admin
      const existingUsers = await db.select().from(users).limit(1);
      if (existingUsers.length === 0) {
        values.role = 'admin';
        updateSet.role = 'admin';
      } else {
        values.role = 'user';
        updateSet.role = 'user';
      }
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

// ============ USER BALANCE QUERIES ============

export async function getUserBalance(userId: number) {
  const db = await getDb();
  if (!db) return null;

  const result = await db.select().from(userBalances).where(eq(userBalances.userId, userId)).limit(1);
  return result.length > 0 ? result[0] : null;
}

export async function initializeUserBalance(userId: number, initialBalance: number = 0) {
  const db = await getDb();
  if (!db) return null;

  const existing = await getUserBalance(userId);
  if (existing) return existing;

  await db.insert(userBalances).values({
    userId,
    balance: initialBalance.toString(),
  });

  return await getUserBalance(userId);
}

export async function updateUserBalance(userId: number, amount: string) {
  const db = await getDb();
  if (!db) return null;

  const balance = await getUserBalance(userId);
  if (!balance) {
    await initializeUserBalance(userId, 0);
  }

  const newBalance = (parseFloat(balance?.balance.toString() || "0") + parseFloat(amount)).toString();

  await db.update(userBalances)
    .set({ balance: newBalance })
    .where(eq(userBalances.userId, userId));

  return await getUserBalance(userId);
}

// ============ CARD CATEGORY QUERIES ============

export async function getAllCategories() {
  const db = await getDb();
  if (!db) return [];

  return await db.select().from(cardCategories).where(eq(cardCategories.isActive, true));
}

export async function getCategoryById(id: number) {
  const db = await getDb();
  if (!db) return null;

  const result = await db.select().from(cardCategories).where(eq(cardCategories.id, id)).limit(1);
  return result.length > 0 ? result[0] : null;
}

export async function createCategory(data: {
  name: string;
  description?: string;
  basePrice: string;
  discountPercentage?: string;
  finalPrice: string;
  offerText?: string;
}) {
  const db = await getDb();
  if (!db) return null;

  const result = await db.insert(cardCategories).values({
    name: data.name,
    description: data.description,
    basePrice: data.basePrice,
    discountPercentage: data.discountPercentage || "0",
    finalPrice: data.finalPrice,
    offerText: data.offerText,
  });

  return result;
}

export async function updateCategory(id: number, data: Partial<{
  name: string;
  description: string;
  basePrice: string;
  discountPercentage: string;
  finalPrice: string;
  offerText: string;
  isActive: boolean;
}>) {
  const db = await getDb();
  if (!db) return null;

  await db.update(cardCategories).set(data).where(eq(cardCategories.id, id));
  return await getCategoryById(id);
}

export async function deleteCategory(id: number) {
  const db = await getDb();
  if (!db) return false;

  await db.update(cardCategories).set({ isActive: false }).where(eq(cardCategories.id, id));
  return true;
}

// ============ CARD QUERIES ============

export async function getAvailableCard(categoryId: number) {
  const db = await getDb();
  if (!db) return null;

  const result = await db.select().from(cards)
    .where(and(eq(cards.categoryId, categoryId), eq(cards.isUsed, false)))
    .limit(1);

  return result.length > 0 ? result[0] : null;
}

export async function markCardAsUsed(cardId: number) {
  const db = await getDb();
  if (!db) return false;

  await db.update(cards).set({ isUsed: true }).where(eq(cards.id, cardId));
  return true;
}

export async function addCards(categoryId: number, codes: string[]) {
  const db = await getDb();
  if (!db) return false;

  const values = codes.map(code => ({
    categoryId,
    code,
  }));

  await db.insert(cards).values(values);
  return true;
}

export async function getCardsByCategory(categoryId: number) {
  const db = await getDb();
  if (!db) return [];

  return await db.select().from(cards).where(eq(cards.categoryId, categoryId));
}

export async function getAvailableCardsCount(categoryId: number) {
  const db = await getDb();
  if (!db) return 0;

  const result = await db.select().from(cards)
    .where(and(eq(cards.categoryId, categoryId), eq(cards.isUsed, false)));

  return result.length;
}

// ============ PURCHASE QUERIES ============

export async function createPurchase(userId: number, cardId: number, categoryId: number, amount: string, cardCode: string) {
  const db = await getDb();
  if (!db) return null;

  const result = await db.insert(purchases).values({
    userId,
    cardId,
    categoryId,
    amount,
    cardCode,
  });

  return result;
}

export async function getUserPurchases(userId: number) {
  const db = await getDb();
  if (!db) return [];

  return await db.select().from(purchases)
    .where(eq(purchases.userId, userId))
    .orderBy(desc(purchases.createdAt));
}

export async function getPurchaseStats() {
  const db = await getDb();
  if (!db) return null;

  const result = await db.select().from(purchases);
  return result;
}

// ============ SUPPORT TICKET QUERIES ============

export async function createSupportTicket(userId: number, subject: string) {
  const db = await getDb();
  if (!db) return null;

  const result = await db.insert(supportTickets).values({
    userId,
    subject,
  });

  return result;
}

export async function getSupportTicketById(id: number) {
  const db = await getDb();
  if (!db) return null;

  const result = await db.select().from(supportTickets).where(eq(supportTickets.id, id)).limit(1);
  return result.length > 0 ? result[0] : null;
}

export async function getUserSupportTickets(userId: number) {
  const db = await getDb();
  if (!db) return [];

  return await db.select().from(supportTickets)
    .where(eq(supportTickets.userId, userId))
    .orderBy(desc(supportTickets.updatedAt));
}

export async function getAllSupportTickets() {
  const db = await getDb();
  if (!db) return [];

  return await db.select().from(supportTickets)
    .orderBy(desc(supportTickets.updatedAt));
}

export async function updateTicketStatus(id: number, status: string) {
  const db = await getDb();
  if (!db) return false;

  await db.update(supportTickets).set({ status: status as any }).where(eq(supportTickets.id, id));
  return true;
}

// ============ SUPPORT MESSAGE QUERIES ============

export async function addSupportMessage(ticketId: number, senderId: number, senderRole: "user" | "admin", message: string, fileUrl?: string, fileType?: string, fileName?: string) {
  const db = await getDb();
  if (!db) return null;

  const result = await db.insert(supportMessages).values({
    ticketId,
    senderId,
    senderRole,
    message,
    fileUrl,
    fileType,
    fileName,
  });

  return result;
}

export async function getTicketMessages(ticketId: number) {
  const db = await getDb();
  if (!db) return [];

  return await db.select().from(supportMessages)
    .where(eq(supportMessages.ticketId, ticketId))
    .orderBy(supportMessages.createdAt);
}

export async function softDeleteMessageForUser(messageId: number) {
  const db = await getDb();
  if (!db) return false;

  await db.update(supportMessages)
    .set({ isDeletedByUser: true })
    .where(eq(supportMessages.id, messageId));

  return true;
}

export async function softDeleteMessageForAdmin(messageId: number) {
  const db = await getDb();
  if (!db) return false;

  await db.update(supportMessages)
    .set({ isDeletedByAdmin: true })
    .where(eq(supportMessages.id, messageId));

  return true;
}

// ============ ADMIN LOG QUERIES ============

export async function logAdminAction(adminId: number, action: string, details?: string) {
  const db = await getDb();
  if (!db) return false;

  await db.insert(adminLogs).values({
    adminId,
    action,
    details,
  });

  return true;
}

export async function getAdminLogs(limit: number = 100) {
  const db = await getDb();
  if (!db) return [];

  return await db.select().from(adminLogs)
    .orderBy(desc(adminLogs.createdAt))
    .limit(limit);
}

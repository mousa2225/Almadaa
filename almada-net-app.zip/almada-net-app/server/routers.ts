import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router, protectedProcedure } from "./_core/trpc";
import { z } from "zod";
import * as db from "./db";
import { TRPCError } from "@trpc/server";
import { notifyOwner } from "./_core/notification";

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  // ============ USER BALANCE ROUTES ============
  balance: router({
    getBalance: protectedProcedure.query(async ({ ctx }) => {
      const balance = await db.getUserBalance(ctx.user.id);
      if (!balance) {
        await db.initializeUserBalance(ctx.user.id, 0);
        return await db.getUserBalance(ctx.user.id);
      }
      return balance;
    }),

    addBalance: protectedProcedure
      .input(z.object({ amount: z.string() }))
      .mutation(async ({ ctx, input }) => {
        if (ctx.user.role !== "admin") {
          throw new TRPCError({ code: "FORBIDDEN" });
        }
        const updated = await db.updateUserBalance(ctx.user.id, input.amount);
        return updated;
      }),
  }),

  // ============ CARD CATEGORY ROUTES ============
  categories: router({
    list: publicProcedure.query(async () => {
      return await db.getAllCategories();
    }),

    get: publicProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => {
        return await db.getCategoryById(input.id);
      }),

    create: protectedProcedure
      .input(z.object({
        name: z.string(),
        description: z.string().optional(),
        basePrice: z.string(),
        discountPercentage: z.string().optional(),
        finalPrice: z.string(),
        offerText: z.string().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        if (ctx.user.role !== "admin") {
          throw new TRPCError({ code: "FORBIDDEN" });
        }
        await db.logAdminAction(ctx.user.id, "CREATE_CATEGORY", JSON.stringify(input));
        return await db.createCategory(input);
      }),

    update: protectedProcedure
      .input(z.object({
        id: z.number(),
        name: z.string().optional(),
        description: z.string().optional(),
        basePrice: z.string().optional(),
        discountPercentage: z.string().optional(),
        finalPrice: z.string().optional(),
        offerText: z.string().optional(),
        isActive: z.boolean().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        if (ctx.user.role !== "admin") {
          throw new TRPCError({ code: "FORBIDDEN" });
        }
        const { id, ...data } = input;
        await db.logAdminAction(ctx.user.id, "UPDATE_CATEGORY", JSON.stringify({ id, ...data }));
        return await db.updateCategory(id, data);
      }),

    delete: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ ctx, input }) => {
        if (ctx.user.role !== "admin") {
          throw new TRPCError({ code: "FORBIDDEN" });
        }
        await db.logAdminAction(ctx.user.id, "DELETE_CATEGORY", JSON.stringify({ id: input.id }));
        return await db.deleteCategory(input.id);
      }),
  }),

  // ============ CARD INVENTORY ROUTES ============
  cards: router({
    addSingle: protectedProcedure
      .input(z.object({
        categoryId: z.number(),
        code: z.string(),
      }))
      .mutation(async ({ ctx, input }) => {
        if (ctx.user.role !== "admin") {
          throw new TRPCError({ code: "FORBIDDEN" });
        }
        await db.logAdminAction(ctx.user.id, "ADD_CARD", JSON.stringify(input));
        return await db.addCards(input.categoryId, [input.code]);
      }),

    addBulk: protectedProcedure
      .input(z.object({
        categoryId: z.number(),
        codes: z.array(z.string()),
      }))
      .mutation(async ({ ctx, input }) => {
        if (ctx.user.role !== "admin") {
          throw new TRPCError({ code: "FORBIDDEN" });
        }
        await db.logAdminAction(ctx.user.id, "ADD_CARDS_BULK", JSON.stringify({ categoryId: input.categoryId, count: input.codes.length }));
        return await db.addCards(input.categoryId, input.codes);
      }),

    getAvailableCount: protectedProcedure
      .input(z.object({ categoryId: z.number() }))
      .query(async ({ ctx, input }) => {
        if (ctx.user.role !== "admin") {
          throw new TRPCError({ code: "FORBIDDEN" });
        }
        return await db.getAvailableCardsCount(input.categoryId);
      }),

    getByCategory: protectedProcedure
      .input(z.object({ categoryId: z.number() }))
      .query(async ({ ctx, input }) => {
        if (ctx.user.role !== "admin") {
          throw new TRPCError({ code: "FORBIDDEN" });
        }
        return await db.getCardsByCategory(input.categoryId);
      }),
  }),

  // ============ PURCHASE ROUTES ============
  purchases: router({
    buyCard: protectedProcedure
      .input(z.object({ categoryId: z.number() }))
      .mutation(async ({ ctx, input }) => {
        const category = await db.getCategoryById(input.categoryId);
        if (!category) {
          throw new TRPCError({ code: "NOT_FOUND", message: "Category not found" });
        }

        const availableCard = await db.getAvailableCard(input.categoryId);
        if (!availableCard) {
          throw new TRPCError({ code: "NOT_FOUND", message: "No available cards in this category" });
        }

        const userBalance = await db.getUserBalance(ctx.user.id);
        const currentBalance = parseFloat(userBalance?.balance.toString() || "0");
        const price = parseFloat(category.finalPrice.toString());

        if (currentBalance < price) {
          throw new TRPCError({ code: "BAD_REQUEST", message: "Insufficient balance" });
        }

        // Deduct balance
        const newBalance = (currentBalance - price).toString();
        await db.updateUserBalance(ctx.user.id, (-price).toString());

        // Mark card as used
        await db.markCardAsUsed(availableCard.id);

        // Create purchase record
        await db.createPurchase(ctx.user.id, availableCard.id, input.categoryId, price.toString(), availableCard.code);

        // Log admin action
        await db.logAdminAction(ctx.user.id, "PURCHASE_CARD", JSON.stringify({ categoryId: input.categoryId, amount: price }));

        // Send notification to owner
        try {
          await notifyOwner({
            title: "🛍️ عملية شراء جديدة",
            content: `المستخدم: ${ctx.user.name}\nالبريد: ${ctx.user.email}\nالفئة: ${category.name}\nالمبلغ: ${price}`,
          });
        } catch (error) {
          console.error("[Notification] Failed to notify owner:", error);
        }

        return {
          success: true,
          card: availableCard,
          newBalance,
        };
      }),

    getHistory: protectedProcedure.query(async ({ ctx }) => {
      return await db.getUserPurchases(ctx.user.id);
    }),

    getStats: protectedProcedure.query(async ({ ctx }) => {
      if (ctx.user.role !== "admin") {
        throw new TRPCError({ code: "FORBIDDEN" });
      }
      const purchasesList = await db.getPurchaseStats();
      const safeList = purchasesList || [];
      return {
        totalPurchases: safeList.length,
        totalRevenue: safeList.reduce((sum, p) => sum + parseFloat(p.amount.toString()), 0),
        purchases: safeList,
      };
    }),
  }),

  // ============ SUPPORT ROUTES ============
  support: router({
    createTicket: protectedProcedure
      .input(z.object({ subject: z.string() }))
      .mutation(async ({ ctx, input }) => {
        return await db.createSupportTicket(ctx.user.id, input.subject);
      }),

    getMyTickets: protectedProcedure.query(async ({ ctx }) => {
      return await db.getUserSupportTickets(ctx.user.id);
    }),

    getAllTickets: protectedProcedure.query(async ({ ctx }) => {
      if (ctx.user.role !== "admin") {
        throw new TRPCError({ code: "FORBIDDEN" });
      }
      return await db.getAllSupportTickets();
    }),

    getTicketMessages: protectedProcedure
      .input(z.object({ ticketId: z.number() }))
      .query(async ({ ctx, input }) => {
        const ticket = await db.getSupportTicketById(input.ticketId);
        if (!ticket) {
          throw new TRPCError({ code: "NOT_FOUND" });
        }

        // Check authorization
        if (ctx.user.role !== "admin" && ticket.userId !== ctx.user.id) {
          throw new TRPCError({ code: "FORBIDDEN" });
        }

        const messages = await db.getTicketMessages(input.ticketId);
        
        // Filter deleted messages based on user role
        return messages.filter(msg => {
          if (ctx.user.role === "admin") {
            return !msg.isDeletedByAdmin;
          } else {
            return !msg.isDeletedByUser;
          }
        });
      }),

    addMessage: protectedProcedure
      .input(z.object({
        ticketId: z.number(),
        message: z.string(),
        fileUrl: z.string().optional(),
        fileType: z.string().optional(),
        fileName: z.string().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        const ticket = await db.getSupportTicketById(input.ticketId);
        if (!ticket) {
          throw new TRPCError({ code: "NOT_FOUND" });
        }

        // Check authorization
        if (ctx.user.role !== "admin" && ticket.userId !== ctx.user.id) {
          throw new TRPCError({ code: "FORBIDDEN" });
        }

        const senderRole = ctx.user.role === "admin" ? "admin" : "user";
        return await db.addSupportMessage(
          input.ticketId,
          ctx.user.id,
          senderRole,
          input.message,
          input.fileUrl,
          input.fileType,
          input.fileName
        );
      }),

    deleteMessage: protectedProcedure
      .input(z.object({ messageId: z.number() }))
      .mutation(async ({ ctx, input }) => {
        // Get message to check ownership
        const messages = await db.getTicketMessages(0); // This is a workaround, should be improved
        
        if (ctx.user.role === "admin") {
          return await db.softDeleteMessageForAdmin(input.messageId);
        } else {
          return await db.softDeleteMessageForUser(input.messageId);
        }
      }),

    updateTicketStatus: protectedProcedure
      .input(z.object({
        ticketId: z.number(),
        status: z.enum(["open", "in_progress", "closed", "resolved"]),
      }))
      .mutation(async ({ ctx, input }) => {
        if (ctx.user.role !== "admin") {
          throw new TRPCError({ code: "FORBIDDEN" });
        }
        return await db.updateTicketStatus(input.ticketId, input.status);
      }),
  }),

  // ============ ADMIN ROUTES ============
  admin: router({
    getUsers: protectedProcedure.query(async ({ ctx }) => {
      if (ctx.user.role !== "admin") {
        throw new TRPCError({ code: "FORBIDDEN" });
      }
      // This would need a query helper to get all users
      // For now, returning empty array
      return [];
    }),

    addUserBalance: protectedProcedure
      .input(z.object({
        userId: z.number(),
        amount: z.string(),
      }))
      .mutation(async ({ ctx, input }) => {
        if (ctx.user.role !== "admin") {
          throw new TRPCError({ code: "FORBIDDEN" });
        }
        await db.logAdminAction(ctx.user.id, "ADD_USER_BALANCE", JSON.stringify(input));
        return await db.updateUserBalance(input.userId, input.amount);
      }),

    getAdminLogs: protectedProcedure.query(async ({ ctx }) => {
      if (ctx.user.role !== "admin") {
        throw new TRPCError({ code: "FORBIDDEN" });
      }
      return await db.getAdminLogs();
    }),
  }),
});

export type AppRouter = typeof appRouter;

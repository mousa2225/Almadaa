# 🚀 دليل نشر موقع المدى نت

## المتطلبات
- Node.js 18+ و pnpm
- قاعدة بيانات MySQL
- متغيرات البيئة المطلوبة

## خطوات التثبيت والتشغيل

### 1. تثبيت المتطلبات
```bash
pnpm install
```

### 2. إعداد متغيرات البيئة
أنشئ ملف `.env` في جذر المشروع:
```
DATABASE_URL=mysql://user:password@localhost:3306/almada_net
JWT_SECRET=your-secret-key-here
VITE_APP_ID=your-app-id
OAUTH_SERVER_URL=https://api.manus.im
VITE_OAUTH_PORTAL_URL=https://oauth.manus.im
OWNER_OPEN_ID=your-owner-id
OWNER_NAME=Admin
BUILT_IN_FORGE_API_URL=https://api.manus.im
BUILT_IN_FORGE_API_KEY=your-forge-key
VITE_FRONTEND_FORGE_API_URL=https://api.manus.im
VITE_FRONTEND_FORGE_API_KEY=your-frontend-key
```

### 3. إعداد قاعدة البيانات
```bash
pnpm drizzle-kit generate
pnpm drizzle-kit migrate
```

### 4. بناء المشروع
```bash
pnpm build
```

### 5. تشغيل الخادم
```bash
pnpm start
```

## النشر على الاستضافة

### خطوات النشر:
1. رفع الملفات على الاستضافة
2. تشغيل `pnpm install`
3. إعداد متغيرات البيئة
4. تشغيل `pnpm build`
5. تشغيل `pnpm start`

## ميزات الموقع

✅ نظام تسجيل دخول OAuth
✅ بيع كروت الإنترنت
✅ لوحة تحكم إدارية
✅ نظام دعم فني
✅ إشعارات فورية
✅ تصميم داكن احترافي

## المستخدم الأول
أول مستخدم يسجل دخول يصير **admin** تلقائياً!

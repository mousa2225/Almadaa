#!/bin/bash
echo "🚀 بدء تشغيل موقع المدى نت..."
node dist/index.js

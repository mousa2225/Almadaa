import { int, mysqlEnum, mysqlTable, text, timestamp, varchar, decimal, boolean, longtext, index } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * User balance table - tracks account balance for each user
 */
export const userBalances = mysqlTable("user_balances", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().references(() => users.id, { onDelete: "cascade" }),
  balance: decimal("balance", { precision: 12, scale: 2 }).default("0").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => ({
  userIdIdx: index("user_id_idx").on(table.userId),
}));

export type UserBalance = typeof userBalances.$inferSelect;
export type InsertUserBalance = typeof userBalances.$inferInsert;

/**
 * Card categories table - stores internet card packages/tiers
 */
export const cardCategories = mysqlTable("card_categories", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  description: text("description"),
  basePrice: decimal("basePrice", { precision: 12, scale: 2 }).notNull(),
  discountPercentage: decimal("discountPercentage", { precision: 5, scale: 2 }).default("0"),
  finalPrice: decimal("finalPrice", { precision: 12, scale: 2 }).notNull(),
  offerText: varchar("offerText", { length: 255 }),
  isActive: boolean("isActive").default(true).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type CardCategory = typeof cardCategories.$inferSelect;
export type InsertCardCategory = typeof cardCategories.$inferInsert;

/**
 * Cards inventory table - stores individual card codes
 */
export const cards = mysqlTable("cards", {
  id: int("id").autoincrement().primaryKey(),
  categoryId: int("categoryId").notNull().references(() => cardCategories.id, { onDelete: "cascade" }),
  code: varchar("code", { length: 255 }).notNull().unique(),
  isUsed: boolean("isUsed").default(false).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => ({
  categoryIdIdx: index("category_id_idx").on(table.categoryId),
  isUsedIdx: index("is_used_idx").on(table.isUsed),
}));

export type Card = typeof cards.$inferSelect;
export type InsertCard = typeof cards.$inferInsert;

/**
 * Purchases table - tracks all card purchases
 */
export const purchases = mysqlTable("purchases", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().references(() => users.id, { onDelete: "cascade" }),
  cardId: int("cardId").notNull().references(() => cards.id, { onDelete: "restrict" }),
  categoryId: int("categoryId").notNull().references(() => cardCategories.id, { onDelete: "restrict" }),
  amount: decimal("amount", { precision: 12, scale: 2 }).notNull(),
  cardCode: varchar("cardCode", { length: 255 }).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (table) => ({
  userIdIdx: index("purchase_user_id_idx").on(table.userId),
  cardIdIdx: index("purchase_card_id_idx").on(table.cardId),
  createdAtIdx: index("purchase_created_at_idx").on(table.createdAt),
}));

export type Purchase = typeof purchases.$inferSelect;
export type InsertPurchase = typeof purchases.$inferInsert;

/**
 * Support tickets table - tracks support conversations
 */
export const supportTickets = mysqlTable("support_tickets", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().references(() => users.id, { onDelete: "cascade" }),
  subject: varchar("subject", { length: 255 }).notNull(),
  status: mysqlEnum("status", ["open", "in_progress", "closed", "resolved"]).default("open").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => ({
  userIdIdx: index("ticket_user_id_idx").on(table.userId),
  statusIdx: index("ticket_status_idx").on(table.status),
}));

export type SupportTicket = typeof supportTickets.$inferSelect;
export type InsertSupportTicket = typeof supportTickets.$inferInsert;

/**
 * Support messages table - stores individual messages in support conversations
 * Supports file attachments (images, videos, audio, etc.)
 */
export const supportMessages = mysqlTable("support_messages", {
  id: int("id").autoincrement().primaryKey(),
  ticketId: int("ticketId").notNull().references(() => supportTickets.id, { onDelete: "cascade" }),
  senderId: int("senderId").notNull().references(() => users.id, { onDelete: "cascade" }),
  senderRole: mysqlEnum("senderRole", ["user", "admin"]).notNull(),
  message: longtext("message").notNull(),
  fileUrl: varchar("fileUrl", { length: 1024 }),
  fileType: varchar("fileType", { length: 50 }),
  fileName: varchar("fileName", { length: 255 }),
  isDeletedByUser: boolean("isDeletedByUser").default(false).notNull(),
  isDeletedByAdmin: boolean("isDeletedByAdmin").default(false).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => ({
  ticketIdIdx: index("message_ticket_id_idx").on(table.ticketId),
  senderIdIdx: index("message_sender_id_idx").on(table.senderId),
}));

export type SupportMessage = typeof supportMessages.$inferSelect;
export type InsertSupportMessage = typeof supportMessages.$inferInsert;

/**
 * Admin logs table - tracks admin actions for audit trail
 */
export const adminLogs = mysqlTable("admin_logs", {
  id: int("id").autoincrement().primaryKey(),
  adminId: int("adminId").notNull().references(() => users.id, { onDelete: "cascade" }),
  action: varchar("action", { length: 255 }).notNull(),
  details: longtext("details"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (table) => ({
  adminIdIdx: index("admin_id_idx").on(table.adminId),
  actionIdx: index("action_idx").on(table.action),
}));

export type AdminLog = typeof adminLogs.$inferSelect;
export type InsertAdminLog = typeof adminLogs.$inferInsert;
